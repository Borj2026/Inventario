# Edge Functions are DISABLED

All Edge Functions in /supabase/functions/ are disabled and should NOT be deployed.

Error 403 occurs when attempting to deploy.

Use direct database connection instead.
